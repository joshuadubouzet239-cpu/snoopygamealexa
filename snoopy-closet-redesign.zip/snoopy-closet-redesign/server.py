from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import webbrowser

ROOT = Path(__file__).parent
PORT = 8000

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

print(f"Snoopy's Closet running at http://localhost:{PORT}")
print("Music: put your MP3 at music/track.mp3")
webbrowser.open(f"http://localhost:{PORT}/index.html")
ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
