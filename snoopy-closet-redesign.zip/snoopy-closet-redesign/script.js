const WARDROBE=[
{id:"cap-red",name:"Cherry cap",kind:"hat",cat:"hats",desc:"A very good hat"},
{id:"beret-blue",name:"Blue beret",kind:"hat",cat:"hats",desc:"For gallery openings"},
{id:"crown",name:"Tiny crown",kind:"hat",cat:"hats",desc:"Quite the entrance"},
{id:"sunhat",name:"Sun hat",kind:"hat",cat:"hats",desc:"Sunny afternoons"},
{id:"sweater-yellow",name:"Sunny sweater",kind:"top",cat:"tops",desc:"Golden hour energy"},
{id:"sweater-red",name:"Red stripe tee",kind:"top",cat:"tops",desc:"A classic stripe"},
{id:"scarf-blue",name:"Sky scarf",kind:"top",cat:"tops",desc:"A breeze-ready layer"},
{id:"raincoat",name:"Rainy day coat",kind:"top",cat:"tops",desc:"Puddle approved"},
{id:"glasses",name:"Round glasses",kind:"accessory",cat:"accessories",desc:"Very thoughtful"},
{id:"bowtie",name:"Dapper bow tie",kind:"accessory",cat:"accessories",desc:"Instantly fancy"},
{id:"flower",name:"Little flower",kind:"accessory",cat:"accessories",desc:"Picked with care"},
{id:"camera",name:"Pocket camera",kind:"accessory",cat:"accessories",desc:"Ready for a photo"},
{id:"scene-park",name:"The park",kind:"background",cat:"backgrounds",desc:"Perfect afternoon"},
{id:"scene-city",name:"Big city",kind:"background",cat:"backgrounds",desc:"Out on the town"},
{id:"scene-night",name:"Starry night",kind:"background",cat:"backgrounds",desc:"After-hours magic"}];
const CHARACTERS=[
{id:"snoopy",name:"Snoopy",note:"The original cool guy"},
{id:"woodstock",name:"Woodstock",note:"Tiny, but mighty"},
{id:"charlie",name:"Charlie Brown",note:"Good grief, great style"}];
const SCENES=[{id:"park",name:"The park"},{id:"city",name:"Big city"},{id:"night",name:"Starry night"}];

function charSVG(id){
if(id==="woodstock")return `<svg viewBox="0 0 220 270"><ellipse cx="110" cy="249" rx="55" ry="10" fill="#0002"/><path d="M81 214c-3-30 8-53 28-64 14-9 34-5 43 10 13 21 8 49-7 64-16 16-52 14-64-10Z" fill="#f4c928" stroke="#222d3a" stroke-width="5"/><path d="M106 161c-9-16-6-39 8-56 7-9 17-17 26-17 13 0 18 14 12 27-6 13-19 18-22 30-3 11 2 21 9 30" fill="#f4c928" stroke="#222d3a" stroke-width="5"/><path d="M134 92c6-10 9-18 5-27M146 96c8-6 15-12 17-22M123 93c-1-11 0-19 5-27" fill="none" stroke="#222d3a" stroke-width="4" stroke-linecap="round"/><circle cx="143" cy="119" r="4" fill="#222d3a"/><path d="m152 127 20 4-19 8" fill="#ef7c27" stroke="#222d3a" stroke-width="4"/><path d="M98 214c-9 11-18 19-30 21M137 214c10 10 18 16 27 20" fill="none" stroke="#222d3a" stroke-width="6" stroke-linecap="round"/></svg>`;
if(id==="charlie")return `<svg viewBox="0 0 220 270"><ellipse cx="110" cy="250" rx="58" ry="10" fill="#0002"/><path d="M75 200c-6 16-8 32-7 47h84c2-18-2-35-8-47" fill="#ce383d" stroke="#222d3a" stroke-width="5"/><path d="M73 205c10 8 64 8 78-1" fill="none" stroke="#f4c928" stroke-width="13"/><path d="M104 213v36M126 213v36M100 248H86M130 248h15" stroke="#222d3a" stroke-width="6" stroke-linecap="round"/><circle cx="110" cy="126" r="48" fill="#f2c89d" stroke="#222d3a" stroke-width="5"/><path d="M65 121c-3-37 13-61 47-61 33 0 49 23 44 59-12-9-22-16-37-13-16 3-31 5-54 15Z" fill="#f2c89d" stroke="#222d3a" stroke-width="5"/><path d="M76 83c10-18 25-26 42-26 19 0 32 9 39 24-18-8-49-6-81 2Z" fill="#6d503c" stroke="#222d3a" stroke-width="5"/><circle cx="93" cy="126" r="3.5"/><circle cx="128" cy="126" r="3.5"/><path d="M100 146c6 4 14 4 20 0" fill="none" stroke="#222d3a" stroke-width="3" stroke-linecap="round"/></svg>`;
return `<svg viewBox="0 0 220 270"><ellipse cx="110" cy="250" rx="62" ry="10" fill="#0002"/><path d="M73 198c3-35 12-54 36-57 27-4 48 11 53 39 3 19 3 42 8 67H57c6-17 12-32 16-49Z" fill="#f8f4e8" stroke="#222d3a" stroke-width="5"/><path d="M75 102c-2-38 17-64 50-63 28 1 50 22 44 54-3 18-13 30-29 37-14 6-43 3-55-9-6-6-9-12-10-19Z" fill="#f8f4e8" stroke="#222d3a" stroke-width="5"/><path d="M76 91c-5-36 2-62 21-76 15-11 35-7 45 3-7 2-12 7-15 16 17 9 25 24 24 43-6 7-13 11-23 13-16 4-34 1-52 1Z" fill="#222d3a"/><ellipse cx="151" cy="110" rx="13" ry="9" fill="#222d3a"/><circle cx="108" cy="98" r="4"/><path d="M116 116c5 4 13 4 19 0" fill="none" stroke="#222d3a" stroke-width="3" stroke-linecap="round"/><path d="M62 135c-20 15-24 35-11 50 12 14 26 3 22-13-2-8-1-19 9-29" fill="#f8f4e8" stroke="#222d3a" stroke-width="5"/></svg>`;
}
function pieceSVG(id){
const common=`viewBox="0 0 100 70"`;
const s={
"cap-red":`<path d="M24 35c10-19 36-24 57-10l-3 12c-17-6-38-5-54 6Z" fill="#ce383d" stroke="#222d3a" stroke-width="4"/><path d="M24 35c-12 1-20 7-21 13 20 3 39-1 56-7" fill="#ef6157" stroke="#222d3a" stroke-width="4"/>`,
"beret-blue":`<path d="M19 43c-2-16 12-29 32-30 19-1 33 10 35 27-19 8-43 9-67 3Z" fill="#4c90b5" stroke="#222d3a" stroke-width="4"/><path d="M14 44c14 6 46 5 69-4" fill="none" stroke="#222d3a" stroke-width="4"/>`,
"crown":`<path d="m22 48 7-29 18 15 10-23 12 23 17-15 5 29Z" fill="#f4c928" stroke="#222d3a" stroke-width="4"/><path d="M23 48h68" stroke="#ce383d" stroke-width="5"/>`,
"sunhat":`<path d="M28 41c1-17 10-28 22-28s21 11 22 28" fill="#f4c928" stroke="#222d3a" stroke-width="4"/><path d="M9 42c19-8 63-8 82 0-18 11-63 11-82 0Z" fill="#f4c928" stroke="#222d3a" stroke-width="4"/>`,
"sweater-yellow":`<path d="M30 10h40l10 14-7 9-5-5v34H32V28l-5 5-7-9Z" fill="#f4c928" stroke="#222d3a" stroke-width="4"/>`,
"sweater-red":`<path d="M30 10h40l10 14-7 9-5-5v34H32V28l-5 5-7-9Z" fill="#ce383d" stroke="#222d3a" stroke-width="4"/><path d="M37 38h26" stroke="#f4c928" stroke-width="7"/>`,
"scarf-blue":`<path d="M20 20c21 13 39 13 60 0l5 8c-25 17-45 17-70 0Z" fill="#4c90b5" stroke="#222d3a" stroke-width="4"/><path d="M42 28v35l12 4 3-36" fill="#74c2d8" stroke="#222d3a" stroke-width="4"/>`,
"raincoat":`<path d="M30 9h40l12 14-8 11-7-5v34H33V29l-7 5-8-11Z" fill="#74c2d8" stroke="#222d3a" stroke-width="4"/><path d="M50 12v47M43 25h14" stroke="#222d3a" stroke-width="3"/>`,
"glasses":`<circle cx="32" cy="35" r="14" fill="none" stroke="#222d3a" stroke-width="4"/><circle cx="68" cy="35" r="14" fill="none" stroke="#222d3a" stroke-width="4"/><path d="M46 35h8M18 34 8 29M82 34l10-5" stroke="#222d3a" stroke-width="4"/>`,
"bowtie":`<path d="M50 37 30 24 19 34l22 14Zm0 0 20-13 11 10-22 17Z" fill="#ce383d" stroke="#222d3a" stroke-width="4"/><circle cx="50" cy="37" r="7" fill="#f4c928" stroke="#222d3a" stroke-width="3"/>`,
"flower":`<path d="M51 32v34" stroke="#3f805c" stroke-width="4"/><circle cx="51" cy="22" r="7" fill="#f4c928" stroke="#222d3a" stroke-width="3"/><circle cx="39" cy="22" r="7" fill="#ce383d" stroke="#222d3a" stroke-width="3"/><circle cx="63" cy="22" r="7" fill="#ce383d" stroke="#222d3a" stroke-width="3"/>`,
"camera":`<rect x="20" y="23" width="60" height="38" rx="8" fill="#4c90b5" stroke="#222d3a" stroke-width="4"/><path d="m34 23 6-8h20l6 8" fill="#74c2d8" stroke="#222d3a" stroke-width="4"/><circle cx="50" cy="42" r="13" fill="#f4c928" stroke="#222d3a" stroke-width="4"/><circle cx="50" cy="42" r="5" fill="#222d3a"/>`};
return `<svg ${common}>${s[id]||`<rect width="100" height="70" rx="8" fill="#eee"/>`}</svg>`;
}

let state={character:"snoopy",scene:"park",category:"hats",outfit:{}};
const $=s=>document.querySelector(s);
function renderItems(){
 $("#items").innerHTML=WARDROBE.filter(x=>x.cat===state.category).map(x=>`<button class="item ${state.outfit[x.kind]===x.id||x.kind==="background"&&state.scene===x.id.replace("scene-","")?"selected":""}" data-id="${x.id}" draggable="true"><span class="artbox">${x.kind==="background"?`<span class="scene-preview ${x.id.replace("scene-","")}"></span>`:pieceSVG(x.id)}</span><b>${x.name}</b><small>${x.kind==="background"?"tap to set scene":"drag or tap"}</small></button>`).join("");
 document.querySelectorAll(".item").forEach(b=>{b.onclick=()=>apply(b.dataset.id);b.ondragstart=e=>e.dataTransfer.setData("piece",b.dataset.id)});
}
function apply(id){
 const p=WARDROBE.find(x=>x.id===id); if(!p)return;
 if(p.kind==="background"){state.scene=id.replace("scene-","");state.category="backgrounds";$(".status").textContent="";status(`${p.name} is set. Now add personality.`)}
 else{state.outfit[p.kind]=id;status(`${p.name} is on ${CHARACTERS.find(x=>x.id===state.character).name}!`)}
 render(); 
}
function status(t){$("#status").textContent=t;$("#noteText").textContent=t}
function renderCharacter(){
 const c=$("#character");c.className=`character ${state.character}`;c.innerHTML=charSVG(state.character)+Object.entries(state.outfit).filter(([k])=>k!=="background").map(([kind,id])=>`<div class="outfit-piece piece-${kind} piece-${id}">${pieceSVG(id)}</div>`).join("");
}
function render(){
 renderItems();renderCharacter();
 $("#stage").className=`stage scene-${state.scene}`;
 $("#modelLabel").textContent=`/ ${CHARACTERS.find(x=>x.id===state.character).name}`;
 $("#pieceCount").textContent=Object.keys(state.outfit).length;
 $("#emptyTip").style.display=Object.keys(state.outfit).length?"none":"block";
 document.querySelectorAll(".tabs button").forEach(x=>x.classList.toggle("active",x.dataset.cat===state.category));
 document.querySelectorAll(".char-choice").forEach(x=>x.classList.toggle("active",x.dataset.id===state.character));
 document.querySelectorAll(".scene-choice").forEach(x=>x.classList.toggle("active",x.dataset.id===state.scene));
}
function renderCharacters(){
 $("#characters").innerHTML=CHARACTERS.map(c=>`<button class="char-choice ${c.id===state.character?"active":""}" data-id="${c.id}"><span class="thumb">${charSVG(c.id)}</span><span><b>${c.name}</b><small>${c.note}</small></span></button>`).join("");
 document.querySelectorAll(".char-choice").forEach(x=>x.onclick=()=>{state.character=x.dataset.id;status(`${CHARACTERS.find(c=>c.id===state.character).name} is ready for a fitting.`);render()});
}
function renderScenes(){
 $("#scenes").innerHTML=SCENES.map(s=>`<button class="scene-choice ${s.id===state.scene?"active":""}" data-id="${s.id}"><span class="${s.id}"></span>${s.name}</button>`).join("");
 document.querySelectorAll(".scene-choice").forEach(x=>x.onclick=()=>{state.scene=x.dataset.id;status(`${SCENES.find(s=>s.id===state.scene).name} is set.`);render()});
}
function save(){
 const saved=JSON.parse(localStorage.getItem("snoopyLooks")||"[]");
 saved.unshift({...state,id:Date.now()});localStorage.setItem("snoopyLooks",JSON.stringify(saved.slice(0,8)));renderGallery();status("Look saved to your little gallery ✿");$("#gallery").scrollIntoView({behavior:"smooth"});
}
function renderGallery(){
 const saved=JSON.parse(localStorage.getItem("snoopyLooks")||"[]");$("#galleryCount").textContent=saved.length;
 $("#galleryGrid").innerHTML=saved.length?saved.map((x,i)=>`<article class="look-card"><div class="mini-stage scene-${x.scene}"><div class="ground"></div><div class="character ${x.character}">${charSVG(x.character)}${Object.entries(x.outfit).map(([kind,id])=>`<div class="outfit-piece piece-${kind}">${pieceSVG(id)}</div>`).join("")}</div></div><div class="look-meta"><b>${CHARACTERS.find(c=>c.id===x.character)?.name}'s look</b><small>${new Date(x.id).toLocaleDateString()} · ${Object.keys(x.outfit).length} pieces</small></div></article>`).join(""):`<div class="gallery-empty">No looks saved yet. Style someone and press <b>Save look</b>.</div>`;
}
document.querySelectorAll(".tabs button").forEach(b=>b.onclick=()=>{state.category=b.dataset.cat;render()});
$("#resetBtn").onclick=()=>{state.outfit={};status("Fresh page, fresh look.");render()};
$("#clearBtn").onclick=()=>{state.outfit={};status("Closet cleared.");render()};
$("#randomBtn").onclick=()=>{state.character=CHARACTERS[Math.floor(Math.random()*3)].id;state.scene=SCENES[Math.floor(Math.random()*3)].id;state.outfit={hat:WARDROBE.filter(x=>x.kind==="hat")[Math.floor(Math.random()*4)].id,top:WARDROBE.filter(x=>x.kind==="top")[Math.floor(Math.random()*4)].id,accessory:WARDROBE.filter(x=>x.kind==="accessory")[Math.floor(Math.random()*4)].id};status("A surprise look appeared ✦");render()};
$("#saveBtn").onclick=save;$("#galleryBtn").onclick=()=>$("#gallery").scrollIntoView();$("#howBtn").onclick=()=>$("#how").scrollIntoView();$("#makeAnother").onclick=()=>window.scrollTo({top:0,behavior:"smooth"});
$("#stage").ondragover=e=>e.preventDefault();$("#stage").ondrop=e=>{e.preventDefault();const id=e.dataTransfer.getData("piece");if(id)apply(id)};

const audio=$("#audio"),play=$("#playBtn"),seek=$("#seek"),vol=$("#volume");
function fmt(s){if(!isFinite(s))return"0:00";return `${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,"0")}`}
function updateAudio(){seek.value=audio.duration?(audio.currentTime/audio.duration)*100:0;$("#time").textContent=`${fmt(audio.currentTime)} / ${fmt(audio.duration)}`}
play.onclick=()=>{if(!audio.src){alert("Put your MP3 in the music folder and run the Python server.");return} audio.paused?audio.play():audio.pause()};
audio.onplay=()=>play.textContent="Ⅱ";audio.onpause=()=>play.textContent="▶";audio.ontimeupdate=updateAudio;audio.onloadedmetadata=updateAudio;seek.oninput=()=>{if(audio.duration)audio.currentTime=(seek.value/100)*audio.duration};vol.oninput=()=>audio.volume=vol.value;audio.volume=.75;
fetch("music/track.mp3").then(r=>{if(r.ok){audio.src="music/track.mp3";$("#trackTitle").textContent="wave to earth — love."}}).catch(()=>{});
renderCharacters();renderScenes();render();renderGallery();
